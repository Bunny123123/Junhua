Este es un recurso local de ejemplo.
